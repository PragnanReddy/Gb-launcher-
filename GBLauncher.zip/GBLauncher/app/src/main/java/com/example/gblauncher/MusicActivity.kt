package com.example.gblauncher

import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

class MusicActivity : Activity() {
    private var tracks: List<Media> = emptyList()
    private var selected = 0
    private var lastIndex = -2
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var sh: Gb.Shell
    private lateinit var list: ListView
    private lateinit var adapter: Gb.RowAdapter
    private lateinit var nowTitle: TextView
    private lateinit var nowTime: TextView
    private lateinit var bar: GbProgress

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sh = Gb.shell(this, "♪ MUSIC", Gb.Keys(
            up = { move(-1) }, down = { move(1) },
            left = { MusicPlayer.prev(this) }, right = { MusicPlayer.next(this) },
            a = { activate() }, b = { finish() },
            select = { MusicPlayer.shuffle = !MusicPlayer.shuffle },
            start = { MusicPlayer.stop() }))

        adapter = Gb.RowAdapter(this, { tracks.size },
            { i -> (tracks[i].title + if (tracks[i].artist.isNotEmpty()) " - " + tracks[i].artist else "").uppercase() },
            { selected }, { if (MusicPlayer.tracks === tracks) MusicPlayer.index else -1 }, "♪")
        list = ListView(this).apply {
            divider = null; setSelector(android.R.color.transparent)
            isVerticalScrollBarEnabled = false
            this.adapter = this@MusicActivity.adapter
            setOnItemClickListener { _, _, pos, _ -> selected = pos; activate() }
        }
        sh.screen.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // now-playing panel
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(0, Gb.dp(this@MusicActivity, 6), 0, 0)
        }
        panel.addView(View(this).apply { setBackgroundColor(Gb.C0) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Gb.dp(this, 2)))
        nowTitle = Gb.tv(this, "- STOPPED -", 14f, Gb.C0).apply { setSingleLine()
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(Gb.dp(this@MusicActivity, 4), Gb.dp(this@MusicActivity, 6), 0, 0) }
        nowTime = Gb.tv(this, "00:00 / 00:00", 12f, Gb.C0).apply {
            setPadding(Gb.dp(this@MusicActivity, 4), 0, 0, Gb.dp(this@MusicActivity, 4)) }
        bar = GbProgress(this).apply { onSeek = { f -> MusicPlayer.seekTo((f * MusicPlayer.duration).toInt()) } }
        panel.addView(nowTitle); panel.addView(nowTime)
        panel.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Gb.dp(this, 26)))
        sh.screen.addView(panel)

        setContentView(sh.root)
        if (Gb.hasPerm(this, "audio")) load() else requestPermissions(arrayOf(Gb.permFor("audio")), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        if (res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED) load()
        else nowTitle.text = "NO PERMISSION"
    }

    override fun onResume() { super.onResume(); tick.run() }
    override fun onPause() { super.onPause(); handler.removeCallbacks(tick) }

    private fun load() {
        tracks = Gb.queryAudio(this)
        if (MusicPlayer.tracks.size == tracks.size && MusicPlayer.index >= 0) {
            MusicPlayer.tracks = tracks; selected = MusicPlayer.index
        }
        if (tracks.isEmpty()) nowTitle.text = "NO MUSIC FOUND"
        adapter.notifyDataSetChanged()
        list.setSelection(selected)
    }

    private fun move(d: Int) {
        if (tracks.isEmpty()) return
        selected = (selected + d).coerceIn(0, tracks.size - 1)
        adapter.notifyDataSetChanged(); list.smoothScrollToPosition(selected)
    }

    private fun activate() {
        if (tracks.isEmpty()) return
        if (MusicPlayer.tracks === tracks && selected == MusicPlayer.index) MusicPlayer.toggle()
        else MusicPlayer.start(this, tracks, selected)
    }

    private val tick = object : Runnable {
        override fun run() {
            val cur = MusicPlayer.current
            if (cur != null && MusicPlayer.tracks === tracks) {
                nowTitle.text = cur.title.uppercase()
                nowTime.text = Gb.fmt(MusicPlayer.position) + " / " + Gb.fmt(MusicPlayer.duration)
                val d = MusicPlayer.duration
                bar.fraction = if (d > 0) MusicPlayer.position.toFloat() / d else 0f
            }
            sh.status.text = (if (MusicPlayer.shuffle) "SHF " else "") +
                (if (MusicPlayer.playing) "▶" else if (cur != null) "❚❚" else "■")
            if (lastIndex != MusicPlayer.index) { lastIndex = MusicPlayer.index; adapter.notifyDataSetChanged() }
            handler.postDelayed(this, 500)
        }
    }
}
