package com.example.gblauncher

import android.app.Activity
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import kotlin.math.min

class VideoActivity : Activity() {
    private var videos: List<Media> = emptyList()
    private var selected = 0
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var sh: Gb.Shell
    private lateinit var list: ListView
    private lateinit var adapter: Gb.RowAdapter

    // player state
    private var mp: MediaPlayer? = null
    private var ready = false
    private var playerRoot: FrameLayout? = null
    private var tex: TextureView? = null
    private var overlay: View? = null
    private var timeText: TextView? = null
    private var playBtn: TextView? = null
    private var bar: GbProgress? = null
    private var tintOn = true
    private var lastTouch = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sh = Gb.shell(this, "▶ VIDEO", Gb.Keys(
            up = { move(-1) }, down = { move(1) },
            a = { play() }, b = { finish() }))
        adapter = Gb.RowAdapter(this, { videos.size },
            { i -> (videos[i].title + "  " + Gb.fmt(videos[i].durationMs.toInt())).uppercase() },
            { selected }, { -1 }, "")
        list = ListView(this).apply {
            divider = null; setSelector(android.R.color.transparent)
            isVerticalScrollBarEnabled = false
            this.adapter = this@VideoActivity.adapter
            setOnItemClickListener { _, _, pos, _ -> selected = pos; play() }
        }
        sh.screen.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(sh.root)
        if (Gb.hasPerm(this, "video")) load() else requestPermissions(arrayOf(Gb.permFor("video")), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        if (res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED) load()
        else sh.status.text = "NO PERMISSION"
    }

    private fun load() {
        videos = Gb.queryVideo(this)
        sh.status.text = if (videos.isEmpty()) "NO VIDEOS" else "${videos.size} FILES"
        adapter.notifyDataSetChanged()
    }

    private fun move(d: Int) {
        if (videos.isEmpty()) return
        selected = (selected + d).coerceIn(0, videos.size - 1)
        adapter.notifyDataSetChanged(); list.smoothScrollToPosition(selected)
    }

    // ---------- player ----------
    private fun play() {
        val m = videos.getOrNull(selected) ?: return
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val t = TextureView(this)
        root.addView(t, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
        t.setOnClickListener { toggleOverlay() }
        t.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) { start(m, Surface(st)) }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean = true
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        root.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> fit() }

        // controls overlay
        val d = { v: Int -> Gb.dp(this, v) }
        val ov = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Gb.C3)
            setPadding(d(10), d(8), d(10), d(10))
        }
        ov.addView(Gb.tv(this, m.title.uppercase(), 13f, Gb.C0).apply {
            setSingleLine(); ellipsize = android.text.TextUtils.TruncateAt.END })
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val tt = Gb.tv(this, "00:00/00:00", 11f, Gb.C0)
        val pb = GbProgress(this).apply { onSeek = { f -> mp?.let { it.seekTo((f * it.duration).toInt()) } } }
        row1.addView(tt)
        row1.addView(pb, LinearLayout.LayoutParams(0, d(24), 1f).apply { leftMargin = d(8) })
        ov.addView(row1, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = d(6) })
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        fun btn(label: String, act: () -> Unit) = Gb.tv(this, label, 14f, Gb.C3).apply {
            setBackgroundColor(Gb.C0); gravity = Gravity.CENTER
            setPadding(d(14), d(8), d(14), d(8)); setOnClickListener { act(); lastTouch = System.currentTimeMillis() }
        }
        val pbtn = btn("❚❚") { togglePause() }
        row2.addView(btn("◀◀ 10") { seekBy(-10000) })
        row2.addView(pbtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = d(8) })
        row2.addView(btn("10 ▶▶") { seekBy(10000) }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = d(8) })
        row2.addView(btn("TINT") { setTint(!tintOn) }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = d(8) })
        ov.addView(row2, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = d(8) })
        root.addView(ov, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        playerRoot = root; tex = t; overlay = ov; timeText = tt; playBtn = pbtn; bar = pb
        lastTouch = System.currentTimeMillis()
        setTint(tintOn)
        setContentView(root)
        handler.post(tick)
    }

    private fun start(m: Media, surface: Surface) {
        mp?.release(); ready = false
        try {
            mp = MediaPlayer().apply {
                setDataSource(this@VideoActivity, m.uri)
                setSurface(surface)
                setOnVideoSizeChangedListener { _, _, _ -> fit() }
                setOnPreparedListener { ready = true; fit(); it.start() }
                setOnCompletionListener { exitPlayer() }
                setOnErrorListener { _, _, _ -> exitPlayer(); true }
                prepareAsync()
            }
        } catch (e: Exception) { exitPlayer() }
    }

    private fun fit() {
        val r = playerRoot ?: return
        val t = tex ?: return
        val p = mp ?: return
        val vw = try { p.videoWidth } catch (e: Exception) { 0 }
        val vh = try { p.videoHeight } catch (e: Exception) { 0 }
        if (vw == 0 || vh == 0 || r.width == 0 || r.height == 0) return
        val s = min(r.width / vw.toFloat(), r.height / vh.toFloat())
        val lp = FrameLayout.LayoutParams((vw * s).toInt(), (vh * s).toInt(), Gravity.CENTER)
        if (t.layoutParams.width != lp.width || t.layoutParams.height != lp.height) t.layoutParams = lp
    }

    /** Game Boy tint: luminance mapped onto the dark-green -> light-green ramp. */
    private fun setTint(on: Boolean) {
        tintOn = on
        val t = tex ?: return
        if (!on) { t.setLayerType(View.LAYER_TYPE_NONE, null); return }
        val sR = (0x9B - 0x0F) / 255f; val sG = (0xBC - 0x38) / 255f
        val cm = ColorMatrix(floatArrayOf(
            0.30f * sR, 0.59f * sR, 0.11f * sR, 0f, 15f,
            0.30f * sG, 0.59f * sG, 0.11f * sG, 0f, 56f,
            0f, 0f, 0f, 0f, 15f,
            0f, 0f, 0f, 1f, 0f))
        t.setLayerType(View.LAYER_TYPE_HARDWARE, Paint().apply { colorFilter = ColorMatrixColorFilter(cm) })
    }

    private fun togglePause() {
        val p = mp ?: return
        if (!ready) return
        if (p.isPlaying) p.pause() else p.start()
    }

    private fun seekBy(ms: Int) {
        val p = mp ?: return
        if (!ready) return
        p.seekTo((p.currentPosition + ms).coerceIn(0, p.duration))
    }

    private fun toggleOverlay() {
        val o = overlay ?: return
        o.visibility = if (o.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        lastTouch = System.currentTimeMillis()
    }

    private val tick = object : Runnable {
        override fun run() {
            val p = mp
            if (p != null && ready && playerRoot != null) {
                try {
                    val pos = p.currentPosition; val dur = p.duration
                    timeText?.text = Gb.fmt(pos) + "/" + Gb.fmt(dur)
                    bar?.fraction = if (dur > 0) pos.toFloat() / dur else 0f
                    playBtn?.text = if (p.isPlaying) "❚❚" else "▶"
                    if (p.isPlaying && overlay?.visibility == View.VISIBLE &&
                        System.currentTimeMillis() - lastTouch > 3500) overlay?.visibility = View.GONE
                } catch (e: Exception) {}
            }
            if (playerRoot != null) handler.postDelayed(this, 500)
        }
    }

    private fun exitPlayer() {
        handler.removeCallbacks(tick)
        mp?.release(); mp = null; ready = false
        playerRoot = null; tex = null; overlay = null
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        setContentView(sh.root)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (playerRoot != null) when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> { seekBy(-10000); return true }
            KeyEvent.KEYCODE_DPAD_RIGHT -> { seekBy(10000); return true }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_SPACE -> { togglePause(); return true }
        }
        return super.onKeyDown(keyCode, event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (playerRoot != null) exitPlayer() else super.onBackPressed() }

    override fun onConfigurationChanged(c: Configuration) { super.onConfigurationChanged(c); playerRoot?.post { fit() } }
    override fun onPause() { super.onPause(); if (ready) try { mp?.pause() } catch (e: Exception) {} }
    override fun onDestroy() { super.onDestroy(); handler.removeCallbacks(tick); mp?.release(); mp = null }
}
